package com.system.perfect.tugas2.fragments;

import android.arch.lifecycle.ViewModel;

public class FavoriteViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
